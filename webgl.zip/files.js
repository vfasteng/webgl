const files=[

    "/scripts/node.js"

    ,"/scripts/red/init.js"

    ,"/scripts/red/factories/compile.js"
    //,"/scripts/red/factories/http.js"
    ,"/scripts/red/factories/watch.js"
    //,"/scripts/red/factories/window.js"

    ,"/scripts/red/directives/click.js"

  
    ,"/scripts/webgl/common.js"
    ,"/scripts/webgl/camera.js"
    ,"/scripts/webgl/scene.js"

    
    ,"/scripts/webgl/buffer.js"

    ,"/scripts/webgl/engine.js"

    ,"/scripts/webgl/geometry.js"
    ,"/scripts/webgl/mat4.js"
    ,"/scripts/webgl/mesh.js"
    ,"/scripts/webgl/shader.js"
    ,"/scripts/webgl/texture.js"
    ,"/scripts/webgl/uniform.js"
    ,"/scripts/webgl/vec3.js"

    ,"/scripts/webgl/render2d.js"

    ,"/scripts/webgl/gltf/model.js"
    ,"/scripts/webgl/gltf/anim.js"
    ,"/scripts/webgl/gltf/skin.js"

  
    ,"/scripts/webgl/scene/cubes.js"
    ,"/scripts/webgl/scene/triangulation.js"
    ,"/scripts/webgl/scene/render2d.js"
    ,"/scripts/webgl/scene/modelGLTF.js"





  
    ,"/scripts/index.js"
]

try{
    module.exports=files
}catch(e){}